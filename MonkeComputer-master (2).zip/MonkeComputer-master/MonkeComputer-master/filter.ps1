param($p1)
& cat log.log | Select-String $p1