#pragma once
#include <string>

namespace TextUtils
{
    std::string toLower(std::string src);
}